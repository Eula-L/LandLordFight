#ifndef MAINDIALOG_H
#define MAINDIALOG_H

#include <QDialog>
#include "card.h"
#include "cardlist.h"
#include <QTimer>
#include <QDebug>
QT_BEGIN_NAMESPACE
namespace Ui { class MainDialog; }
QT_END_NAMESPACE

class MainDialog : public QDialog
{
    Q_OBJECT

public:
    MainDialog(QWidget *parent = nullptr);
    ~MainDialog();

private slots:
    void on_pb_quickStart_clicked();

    void on_pb_goHome_clicked();

    void on_pb_next_2_clicked();

    void on_pb_test_clicked();

    void slot_setBackGround();

    void slot_startOneGame();

    void slot_refreshAllCardList();

    void on_pb_playCard_clicked();

private:
    Ui::MainDialog *ui;
    CardList m_cardList[CARDLIST_TYPE_COUNT];
    QTimer m_timerRefresh;//刷新显示定时器
};
#endif // MAINDIALOG_H
