#include "maindialog.h"
#include "ui_maindialog.h"

MainDialog::MainDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::MainDialog)
{
    ui->setupUi(this);
    //最小化最大化关闭按钮
    this->setWindowFlags(Qt::WindowMinMaxButtonsHint|Qt::WindowCloseButtonHint);
    //窗口标题
    this->setWindowTitle("斗地主");
    //进入开始界面
    //界面索引0
    ui->sw_page->setCurrentIndex(0);
    //设置所有背景为统一的，但是开始界面、结算界面上面有图片覆盖
    slot_setBackGround();
    //牌堆数组初始化
    //创建了八个管理牌的牌堆
    for(int i=0;i<CARDLIST_TYPE_COUNT;i++)
    {
        m_cardList[i].setCardListType(i);
    }
    connect(&m_timerRefresh,SIGNAL(timeout()),
            this,SLOT(slot_refreshAllCardList()));
}

MainDialog::~MainDialog()
{
    delete ui;
}

//点击快速开始
void MainDialog::on_pb_quickStart_clicked()
{
    ui->sw_page->setCurrentIndex(1);
    slot_startOneGame();
}

//点击下一局
void MainDialog::on_pb_goHome_clicked()
{
    ui->sw_page->setCurrentIndex(1);
}

//点击结束，回到home页面
void MainDialog::on_pb_next_2_clicked()
{
    ui->sw_page->setCurrentIndex(0);
}

//出结果
void MainDialog::on_pb_test_clicked()
{
    ui->sw_page->setCurrentIndex(2);
}
#include <QPalette>
//设置背景，game界面
void MainDialog::slot_setBackGround()
{
    //调色板
    QPalette p = this->palette();
    //设置画刷 设置图片
    QPixmap pixmap(":/image/bk.png");
    p.setBrush(QPalette::Background,QBrush(pixmap));
    //设置调色板 //所有的背景都被设置成了这样，只不过另外两个上面有lable覆盖
    this->setPalette(p);

}

void MainDialog::slot_startOneGame()
{
    //1、创建总牌堆
    for(int i=0;i<54;i++)
    {
        //创建牌
        Card* card = new Card(i,this->ui->page_game);
        card->setCardPositive(false);
        m_cardList[CARDLIST_WHOLE].addCard(card);
    }

    //洗牌
    m_cardList[CARDLIST_WHOLE].shuffle();
    //使用定时器
    m_timerRefresh.start(1000/10);
    //总牌堆显示
    //m_cardList[CARDLIST_WHOLE].cardShow();
    //总牌堆打印
    m_cardList[CARDLIST_WHOLE].cardPrint();

    //发牌 +动画
    //1、三家用户牌
    int i=0;
    Card* card = nullptr;
    for(i=0;i<51;i+=3)
    {
        for(int j=0;j<3;j++)
        {
            _sleep(50);
            slot_refreshAllCardList();
            QCoreApplication::processEvents(QEventLoop::AllEvents,100);


            card = m_cardList[CARDLIST_WHOLE].getOneCard();
            //TODO：在这里可以加动画，写一个牌缓慢移动的循环的函数，不能移动太快
            m_cardList[CARDLIST_LIFT_PLAYER+j].addCard(card);
        }
    }
    _sleep(100);

    //2、地主牌
    while(i<54)
    {
        _sleep(100);
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
        slot_refreshAllCardList();
        card = m_cardList[CARDLIST_WHOLE].getOneCard();
        m_cardList[CARDLIST_LORD].addCard(card);
        i++;
    }

    //排序
    //玩家手牌排序
    i=0;
    while(i<3)
    {
        m_cardList[CARDLIST_LIFT_PLAYER+i].cardSort();
        i++;
    }
    //地主牌排序
    m_cardList[CARDLIST_LORD].cardSort();

    //显示
//    i=0;
//    while(i<3)
//    {
//        m_cardList[CARDLIST_LIFT_PLAYER+i].cardShow();
//        i++;
//    }

    //打印牌
    i=0;
    while(i<3)
    {
        if(i==0)
        {
            qDebug()<<"左玩家";
        }
        else if(i==1)
        {
            qDebug()<<"中间玩家";
        }
        else
        {
            qDebug()<<"右玩家";
        }
        m_cardList[CARDLIST_LIFT_PLAYER+i].cardPrint();
        i++;
    }
    m_cardList[CARDLIST_LORD].cardPrint();
}

void MainDialog::slot_refreshAllCardList()
{
    for(int i=0;i<CARDLIST_TYPE_COUNT;i++)
    {
        m_cardList[i].cardShow();
    }
}


void MainDialog::on_pb_playCard_clicked()
{
    //选择 出牌
    //首先清掉上一轮玩家在外面的手牌-》但是实际上应该是在回合开始的时候清掉
    //TODO: 先判断选中的牌是否符合出牌规则


    //符合
    //获得选中牌
    QList<Card* > lst = m_cardList[CARDLIST_MID_PLAYER].getSelectedCards();
    //将选择的牌添加到玩家out牌堆
    m_cardList[CARDLIST_MID_PLAYER_OUT].addCard(lst);

    //删除选中
    m_cardList[CARDLIST_MID_PLAYER].deleteSelectedCards();
    //玩家out牌堆显示
}

